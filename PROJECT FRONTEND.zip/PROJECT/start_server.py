#!/usr/bin/env python3
"""
Health Lab Backend Server Startup Script
This script provides easy server management for the Alzheimer's disease detection system.
"""

import os
import sys
import argparse
import logging
import subprocess
import time
from datetime import datetime
import json
import signal
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class HealthLabServer:
    def __init__(self, host='0.0.0.0', port=5000, debug=False):
        self.host = host
        self.port = port
        self.debug = debug
        self.server_process = None
        self.is_running = False
        
        # Create necessary directories
        self.create_directories()
        
    def create_directories(self):
        """Create necessary directories for the application"""
        directories = [
            'logs',
            'uploads',
            'results',
            'models',
            'data',
            'plots'
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            logger.info(f"Created directory: {directory}")
    
    def check_dependencies(self):
        """Check if all required dependencies are installed"""
        required_packages = [
            'flask',
            'flask-cors',
            'tensorflow',
            'numpy',
            'pillow',
            'opencv-python',
            'scikit-learn',
            'matplotlib',
            'seaborn',
            'pandas'
        ]
        
        missing_packages = []
        
        for package in required_packages:
            try:
                __import__(package.replace('-', '_'))
                logger.info(f"✓ {package} is installed")
            except ImportError:
                missing_packages.append(package)
                logger.warning(f"✗ {package} is missing")
        
        if missing_packages:
            logger.error(f"Missing packages: {', '.join(missing_packages)}")
            logger.info("Please install missing packages using: pip install -r requirements.txt")
            return False
        
        logger.info("All dependencies are installed ✓")
        return True
    
    def start_server(self):
        """Start the Flask server"""
        try:
            logger.info("Starting Health Lab Backend Server...")
            logger.info(f"Server will be available at: http://{self.host}:{self.port}")
            
            # Set environment variables
            env = os.environ.copy()
            env['FLASK_ENV'] = 'development' if self.debug else 'production'
            env['FLASK_DEBUG'] = '1' if self.debug else '0'
            
            # Start the server process
            cmd = [sys.executable, 'app.py']
            self.server_process = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.is_running = True
            logger.info(f"Server started with PID: {self.server_process.pid}")
            
            # Monitor server output
            self.monitor_server()
            
        except Exception as e:
            logger.error(f"Error starting server: {e}")
            return False
    
    def monitor_server(self):
        """Monitor server output and status"""
        def read_output(pipe, prefix):
            for line in iter(pipe.readline, ''):
                if line:
                    logger.info(f"[{prefix}] {line.strip()}")
        
        # Start output monitoring threads
        stdout_thread = threading.Thread(
            target=read_output, 
            args=(self.server_process.stdout, 'STDOUT')
        )
        stderr_thread = threading.Thread(
            target=read_output, 
            args=(self.server_process.stderr, 'STDERR')
        )
        
        stdout_thread.daemon = True
        stderr_thread.daemon = True
        stdout_thread.start()
        stderr_thread.start()
        
        # Wait for server to start
        time.sleep(3)
        
        # Check if server is running
        if self.server_process.poll() is None:
            logger.info("✅ Server is running successfully!")
            logger.info(f"🌐 Access the application at: http://{self.host}:{self.port}")
            logger.info("📊 Health check: http://localhost:5000/api/health")
            logger.info("📈 Statistics: http://localhost:5000/api/stats")
            logger.info("🛑 Press Ctrl+C to stop the server")
            
            try:
                # Keep the main thread alive
                while self.is_running and self.server_process.poll() is None:
                    time.sleep(1)
            except KeyboardInterrupt:
                logger.info("Received interrupt signal. Stopping server...")
                self.stop_server()
        else:
            logger.error("❌ Server failed to start")
            self.print_server_error()
    
    def print_server_error(self):
        """Print server error output"""
        if self.server_process:
            stdout, stderr = self.server_process.communicate()
            if stdout:
                logger.error(f"STDOUT: {stdout}")
            if stderr:
                logger.error(f"STDERR: {stderr}")
    
    def stop_server(self):
        """Stop the Flask server"""
        if self.server_process and self.is_running:
            logger.info("Stopping server...")
            self.is_running = False
            
            # Send SIGTERM to the process
            self.server_process.terminate()
            
            # Wait for graceful shutdown
            try:
                self.server_process.wait(timeout=10)
                logger.info("✅ Server stopped gracefully")
            except subprocess.TimeoutExpired:
                logger.warning("Server didn't stop gracefully, forcing termination...")
                self.server_process.kill()
                self.server_process.wait()
                logger.info("✅ Server stopped forcefully")
    
    def check_server_status(self):
        """Check if the server is running"""
        try:
            import requests
            response = requests.get(f"http://{self.host}:{self.port}/api/health", timeout=5)
            if response.status_code == 200:
                logger.info("✅ Server is running and healthy")
                return True
            else:
                logger.warning("⚠️ Server is running but health check failed")
                return False
        except Exception as e:
            logger.error(f"❌ Server is not running: {e}")
            return False
    
    def get_server_info(self):
        """Get server information and statistics"""
        try:
            import requests
            
            # Health check
            health_response = requests.get(f"http://{self.host}:{self.port}/api/health", timeout=5)
            health_data = health_response.json() if health_response.status_code == 200 else None
            
            # Statistics
            stats_response = requests.get(f"http://{self.host}:{self.port}/api/stats", timeout=5)
            stats_data = stats_response.json() if stats_response.status_code == 200 else None
            
            return {
                'health': health_data,
                'stats': stats_data,
                'server_url': f"http://{self.host}:{self.port}",
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error getting server info: {e}")
            return None

def main():
    """Main function to handle command line arguments and start server"""
    parser = argparse.ArgumentParser(description='Health Lab Backend Server')
    parser.add_argument('--host', default='0.0.0.0', help='Server host (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, default=5000, help='Server port (default: 5000)')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('--check-deps', action='store_true', help='Check dependencies only')
    parser.add_argument('--status', action='store_true', help='Check server status')
    parser.add_argument('--info', action='store_true', help='Get server information')
    
    args = parser.parse_args()
    
    # Create server instance
    server = HealthLabServer(host=args.host, port=args.port, debug=args.debug)
    
    # Handle different commands
    if args.check_deps:
        print("🔍 Checking dependencies...")
        if server.check_dependencies():
            print("✅ All dependencies are installed")
            sys.exit(0)
        else:
            print("❌ Some dependencies are missing")
            sys.exit(1)
    
    elif args.status:
        print("🔍 Checking server status...")
        if server.check_server_status():
            sys.exit(0)
        else:
            sys.exit(1)
    
    elif args.info:
        print("📊 Getting server information...")
        info = server.get_server_info()
        if info:
            print(json.dumps(info, indent=2))
            sys.exit(0)
        else:
            print("❌ Could not get server information")
            sys.exit(1)
    
    else:
        # Start server
        print("🚀 Starting Health Lab Backend Server...")
        print("=" * 60)
        
        # Check dependencies first
        if not server.check_dependencies():
            print("❌ Please install missing dependencies before starting the server")
            sys.exit(1)
        
        # Start the server
        try:
            server.start_server()
        except KeyboardInterrupt:
            print("\n🛑 Server interrupted by user")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            sys.exit(1)

if __name__ == "__main__":
    main() 