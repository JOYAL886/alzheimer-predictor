#!/usr/bin/env python3
"""
Example MRI Analysis Script
This script demonstrates how to use the MRI processor for Alzheimer's disease detection.
"""

import os
import sys
from mri_processor import MRIScanProcessor
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw

def create_sample_mri_image(output_path: str = "sample_mri_scan.png"):
    """
    Create a sample MRI-like image for testing
    
    Args:
        output_path: Path to save the sample image
    """
    try:
        # Create a 224x224 image with brain-like patterns
        img = Image.new('RGB', (224, 224), color='white')
        draw = ImageDraw.Draw(img)
        
        # Draw brain-like structure
        # Main brain outline
        draw.ellipse([20, 20, 204, 204], outline='gray', width=3, fill='lightgray')
        
        # Brain hemispheres
        draw.ellipse([30, 40, 100, 180], outline='darkgray', width=2, fill='white')
        draw.ellipse([124, 40, 194, 180], outline='darkgray', width=2, fill='white')
        
        # Brain folds (sulci)
        for i in range(5):
            y = 60 + i * 25
            draw.line([(40, y), (90, y)], fill='gray', width=1)
            draw.line([(134, y), (184, y)], fill='gray', width=1)
        
        # Ventricles (fluid-filled spaces)
        draw.ellipse([85, 80, 139, 140], outline='black', width=2, fill='white')
        
        # Add some texture
        for _ in range(50):
            x = np.random.randint(30, 194)
            y = np.random.randint(30, 194)
            draw.point((x, y), fill='gray')
        
        # Save the image
        img.save(output_path)
        print(f"✅ Sample MRI image created: {output_path}")
        return output_path
        
    except Exception as e:
        print(f"❌ Error creating sample image: {e}")
        return None

def demonstrate_mri_analysis():
    """Demonstrate the MRI analysis process"""
    print("🧠 MRI Analysis Demonstration")
    print("=" * 50)
    
    # Initialize the processor
    print("\n1. Initializing MRI Processor...")
    processor = MRIScanProcessor()
    print("✅ Processor initialized successfully")
    
    # Create a sample MRI image
    print("\n2. Creating sample MRI image...")
    sample_image_path = create_sample_mri_image()
    if not sample_image_path:
        print("❌ Failed to create sample image")
        return
    
    # Analyze the MRI scan
    print("\n3. Analyzing MRI scan...")
    analysis = processor.predict_alzheimers_stage(sample_image_path)
    
    if 'error' in analysis:
        print(f"❌ Analysis failed: {analysis['error']}")
        return
    
    # Display results
    print("\n4. Analysis Results:")
    print("-" * 30)
    print(f"Predicted Stage: {analysis['predicted_stage']}")
    print(f"Confidence: {analysis['confidence']:.3f}")
    print(f"Severity Level: {analysis['severity_level']}")
    print(f"Model Used: {analysis['model_used']}")
    
    print("\nConfidence Scores:")
    for stage, score in analysis['confidence_scores'].items():
        print(f"  {stage}: {score:.3f}")
    
    print("\nRecommendations:")
    for i, rec in enumerate(analysis['recommendations'], 1):
        print(f"  {i}. {rec}")
    
    # Create visualization
    print("\n5. Creating analysis visualization...")
    viz_path = processor.create_analysis_visualization(sample_image_path, analysis)
    if viz_path:
        print(f"✅ Visualization saved: {viz_path}")
    
    # Generate report
    print("\n6. Generating analysis report...")
    report_path = processor.generate_report(analysis)
    if report_path:
        print(f"✅ Report saved: {report_path}")
    
    print("\n🎉 Analysis demonstration completed!")

def demonstrate_batch_processing():
    """Demonstrate batch processing of multiple MRI scans"""
    print("\n📊 Batch Processing Demonstration")
    print("=" * 50)
    
    # Initialize processor
    processor = MRIScanProcessor()
    
    # Create multiple sample images
    sample_images = []
    for i in range(3):
        image_path = f"sample_mri_{i+1}.png"
        if create_sample_mri_image(image_path):
            sample_images.append(image_path)
    
    if not sample_images:
        print("❌ Failed to create sample images for batch processing")
        return
    
    # Process all images
    print(f"\nProcessing {len(sample_images)} MRI scans...")
    results = processor.batch_process(sample_images)
    
    # Display batch results
    print("\nBatch Processing Results:")
    print("-" * 30)
    
    for i, result in enumerate(results):
        if 'error' in result:
            print(f"Scan {i+1}: ❌ {result['error']}")
        else:
            print(f"Scan {i+1}: ✅ {result['predicted_stage']} "
                  f"(confidence: {result['confidence']:.3f})")
    
    # Clean up sample images
    for image_path in sample_images:
        try:
            os.remove(image_path)
        except:
            pass

def demonstrate_feature_extraction():
    """Demonstrate feature extraction from MRI scans"""
    print("\n🔍 Feature Extraction Demonstration")
    print("=" * 50)
    
    # Initialize processor
    processor = MRIScanProcessor()
    
    # Create sample image
    sample_image_path = create_sample_mri_image("feature_test_image.png")
    if not sample_image_path:
        return
    
    # Preprocess image
    processed_image = processor.preprocess_mri_scan(sample_image_path)
    if processed_image is None:
        print("❌ Failed to preprocess image")
        return
    
    # Extract features
    features = processor.extract_features(processed_image[0])
    
    print(f"\nExtracted {len(features)} features:")
    print("-" * 30)
    
    for feature_name, feature_value in features.items():
        print(f"{feature_name}: {feature_value:.4f}")
    
    # Clean up
    try:
        os.remove(sample_image_path)
    except:
        pass

def main():
    """Main demonstration function"""
    print("🧠 MRI Scan Analysis for Alzheimer's Disease Detection")
    print("=" * 60)
    
    try:
        # Run demonstrations
        demonstrate_mri_analysis()
        demonstrate_batch_processing()
        demonstrate_feature_extraction()
        
        print("\n" + "=" * 60)
        print("✅ All demonstrations completed successfully!")
        print("\n📋 Key Features Demonstrated:")
        print("• MRI scan preprocessing and enhancement")
        print("• Feature extraction and analysis")
        print("• Alzheimer's disease stage prediction")
        print("• Confidence scoring and recommendations")
        print("• Visualization and reporting")
        print("• Batch processing capabilities")
        
    except Exception as e:
        print(f"\n❌ Demonstration failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
