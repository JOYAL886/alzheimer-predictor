"""
Health Lab Configuration
Centralized configuration settings for the Alzheimer's disease detection system.
"""

import os
from datetime import datetime

class Config:
    """Base configuration class"""
    
    # Application settings
    APP_NAME = "Health Lab"
    APP_VERSION = "1.0.0"
    APP_DESCRIPTION = "Alzheimer's Disease Detection System"
    
    # Server settings
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', 5000))
    DEBUG = os.getenv('FLASK_DEBUG', '0') == '1'
    
    # File upload settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'tiff', 'bmp'}
    UPLOAD_FOLDER = 'uploads'
    RESULTS_FOLDER = 'results'
    
    # Model settings
    MODEL_PATH = 'models'
    MODEL_FILENAME = 'best_model.h5'
    IMG_SIZE = (224, 224)
    CLASS_NAMES = ['NonDemented', 'VeryMildDemented', 'MildDemented', 'ModerateDemented']
    
    # Training settings
    BATCH_SIZE = 32
    EPOCHS = 50
    LEARNING_RATE = 0.001
    VALIDATION_SPLIT = 0.2
    
    # Data augmentation settings
    ROTATION_RANGE = 20
    WIDTH_SHIFT_RANGE = 0.2
    HEIGHT_SHIFT_RANGE = 0.2
    SHEAR_RANGE = 0.2
    ZOOM_RANGE = 0.2
    HORIZONTAL_FLIP = True
    
    # Logging settings
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    LOG_FILE = 'logs/app.log'
    
    # Security settings
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-change-in-production')
    CORS_ORIGINS = ['http://localhost:3000', 'http://localhost:5000']
    
    # API settings
    API_PREFIX = '/api'
    HEALTH_ENDPOINT = '/health'
    STATS_ENDPOINT = '/stats'
    PREDICT_ENDPOINT = '/predict'
    
    # Database settings (for future use)
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///healthlab.db')
    
    # Email settings (for future use)
    MAIL_SERVER = os.getenv('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.getenv('MAIL_PORT', 587))
    MAIL_USE_TLS = os.getenv('MAIL_USE_TLS', 'true').lower() == 'true'
    MAIL_USERNAME = os.getenv('MAIL_USERNAME')
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD')
    
    @classmethod
    def get_model_path(cls):
        """Get the full path to the model file"""
        return os.path.join(cls.MODEL_PATH, cls.MODEL_FILENAME)
    
    @classmethod
    def get_upload_path(cls):
        """Get the upload directory path"""
        return cls.UPLOAD_FOLDER
    
    @classmethod
    def get_results_path(cls):
        """Get the results directory path"""
        return cls.RESULTS_FOLDER
    
    @classmethod
    def create_directories(cls):
        """Create necessary directories"""
        directories = [
            cls.UPLOAD_FOLDER,
            cls.RESULTS_FOLDER,
            cls.MODEL_PATH,
            'logs',
            'data',
            'plots'
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    @classmethod
    def allowed_file(cls, filename):
        """Check if file extension is allowed"""
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in cls.ALLOWED_EXTENSIONS
    
    @classmethod
    def get_class_names(cls):
        """Get the class names for classification"""
        return cls.CLASS_NAMES
    
    @classmethod
    def get_img_size(cls):
        """Get the image size for model input"""
        return cls.IMG_SIZE

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    LOG_LEVEL = 'DEBUG'

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    LOG_LEVEL = 'WARNING'
    
    # Override with production settings
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', 5000))
    SECRET_KEY = os.getenv('SECRET_KEY')

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DEBUG = True
    LOG_LEVEL = 'DEBUG'
    
    # Use test directories
    UPLOAD_FOLDER = 'test_uploads'
    RESULTS_FOLDER = 'test_results'
    MODEL_PATH = 'test_models'

# Configuration mapping
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config(config_name=None):
    """Get configuration class based on environment"""
    if config_name is None:
        config_name = os.getenv('FLASK_ENV', 'development')
    
    return config.get(config_name, config['default'])

# Application info
APP_INFO = {
    'name': Config.APP_NAME,
    'version': Config.APP_VERSION,
    'description': Config.APP_DESCRIPTION,
    'startup_time': datetime.now().isoformat(),
    'config': {
        'host': Config.HOST,
        'port': Config.PORT,
        'debug': Config.DEBUG,
        'model_path': Config.get_model_path(),
        'upload_folder': Config.get_upload_path(),
        'results_folder': Config.get_results_path(),
        'allowed_extensions': list(Config.ALLOWED_EXTENSIONS),
        'max_file_size': Config.MAX_CONTENT_LENGTH,
        'class_names': Config.get_class_names(),
        'img_size': Config.get_img_size()
    }
}
