#!/usr/bin/env python3
"""
MRI Scan Processor for Alzheimer's Disease Detection
This module provides comprehensive MRI processing and Alzheimer's disease classification.
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image, ImageEnhance, ImageFilter
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import tensorflow as tf
from tensorflow import keras
import logging
import os
from datetime import datetime
import json
from typing import Dict, List, Tuple, Optional, Any
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MRIScanProcessor:
    """
    Comprehensive MRI scan processor for Alzheimer's disease detection
    """
    
    def __init__(self, model_path: str = None):
        """
        Initialize the MRI processor
        
        Args:
            model_path: Path to the trained model file
        """
        self.model = None
        self.scaler = StandardScaler()
        self.class_names = ['NonDemented', 'VeryMildDemented', 'MildDemented', 'ModerateDemented']
        self.img_size = (224, 224)
        
        # Load model if path provided
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
        else:
            self.create_default_model()
        
        # Processing parameters
        self.contrast_factor = 1.2
        self.brightness_factor = 1.1
        self.sharpen_factor = 1.5
        
        logger.info("MRI Scan Processor initialized successfully")
    
    def create_default_model(self):
        """Create a default CNN model for demonstration"""
        try:
            model = keras.Sequential([
                # Input layer
                keras.layers.Input(shape=(224, 224, 3)),
                
                # First convolutional block
                keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.MaxPooling2D((2, 2)),
                keras.layers.Dropout(0.25),
                
                # Second convolutional block
                keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.MaxPooling2D((2, 2)),
                keras.layers.Dropout(0.25),
                
                # Third convolutional block
                keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.MaxPooling2D((2, 2)),
                keras.layers.Dropout(0.25),
                
                # Fourth convolutional block
                keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
                keras.layers.BatchNormalization(),
                keras.layers.MaxPooling2D((2, 2)),
                keras.layers.Dropout(0.25),
                
                # Flatten and dense layers
                keras.layers.Flatten(),
                keras.layers.Dense(512, activation='relu'),
                keras.layers.BatchNormalization(),
                keras.layers.Dropout(0.5),
                keras.layers.Dense(256, activation='relu'),
                keras.layers.BatchNormalization(),
                keras.layers.Dropout(0.5),
                keras.layers.Dense(len(self.class_names), activation='softmax')
            ])
            
            model.compile(
                optimizer=keras.optimizers.Adam(learning_rate=0.001),
                loss='categorical_crossentropy',
                metrics=['accuracy', 'precision', 'recall']
            )
            
            self.model = model
            logger.info("Default model created successfully")
            
        except Exception as e:
            logger.error(f"Error creating default model: {e}")
            self.model = None
    
    def load_model(self, model_path: str) -> bool:
        """
        Load a trained model from file
        
        Args:
            model_path: Path to the model file
            
        Returns:
            bool: True if model loaded successfully
        """
        try:
            self.model = keras.models.load_model(model_path)
            logger.info(f"Model loaded successfully from {model_path}")
            return True
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            return False
    
    def preprocess_mri_scan(self, image_path: str) -> Optional[np.ndarray]:
        """
        Comprehensive preprocessing of MRI scan
        
        Args:
            image_path: Path to the MRI image file
            
        Returns:
            Preprocessed image array or None if error
        """
        try:
            # Load image
            if isinstance(image_path, str):
                image = cv2.imread(image_path)
                if image is None:
                    raise ValueError("Could not load image from path")
            else:
                image = image_path
            
            # Convert BGR to RGB
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Convert to PIL for advanced processing
            pil_image = Image.fromarray(image)
            
            # Apply image enhancements
            pil_image = self._enhance_image(pil_image)
            
            # Convert back to numpy array
            enhanced_image = np.array(pil_image)
            
            # Resize to model input size
            resized_image = cv2.resize(enhanced_image, self.img_size)
            
            # Normalize pixel values
            normalized_image = resized_image.astype(np.float32) / 255.0
            
            # Add batch dimension
            processed_image = np.expand_dims(normalized_image, axis=0)
            
            logger.info(f"MRI scan preprocessed successfully: {processed_image.shape}")
            return processed_image
            
        except Exception as e:
            logger.error(f"Error preprocessing MRI scan: {e}")
            return None
    
    def _enhance_image(self, image: Image.Image) -> Image.Image:
        """
        Apply image enhancements for better analysis
        
        Args:
            image: PIL Image object
            
        Returns:
            Enhanced PIL Image
        """
        try:
            # Convert to grayscale if needed
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Apply contrast enhancement
            enhancer = ImageEnhance.Contrast(image)
            image = enhancer.enhance(self.contrast_factor)
            
            # Apply brightness adjustment
            enhancer = ImageEnhance.Brightness(image)
            image = enhancer.enhance(self.brightness_factor)
            
            # Apply sharpening
            enhancer = ImageEnhance.Sharpness(image)
            image = enhancer.enhance(self.sharpen_factor)
            
            # Apply noise reduction
            image = image.filter(ImageFilter.MedianFilter(size=3))
            
            return image
            
        except Exception as e:
            logger.error(f"Error enhancing image: {e}")
            return image
    
    def extract_features(self, image: np.ndarray) -> Dict[str, Any]:
        """
        Extract features from MRI scan for analysis
        
        Args:
            image: Preprocessed image array
            
        Returns:
            Dictionary of extracted features
        """
        try:
            features = {}
            
            # Convert to grayscale for feature extraction
            if len(image.shape) == 3:
                gray_image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            else:
                gray_image = image
            
            # Basic statistical features
            features['mean_intensity'] = np.mean(gray_image)
            features['std_intensity'] = np.std(gray_image)
            features['min_intensity'] = np.min(gray_image)
            features['max_intensity'] = np.max(gray_image)
            
            # Histogram features
            hist, bins = np.histogram(gray_image.flatten(), bins=256, range=[0, 256])
            features['histogram_peaks'] = len(hist[hist > np.mean(hist) * 1.5])
            features['histogram_entropy'] = -np.sum(hist * np.log2(hist + 1e-10))
            
            # Texture features using GLCM-like approach
            features['texture_variance'] = np.var(gray_image)
            features['texture_skewness'] = self._calculate_skewness(gray_image)
            features['texture_kurtosis'] = self._calculate_kurtosis(gray_image)
            
            # Edge features
            edges = cv2.Canny(gray_image, 50, 150)
            features['edge_density'] = np.sum(edges > 0) / edges.size
            
            # Regional features (divide image into quadrants)
            h, w = gray_image.shape
            quadrants = [
                gray_image[:h//2, :w//2],  # Top-left
                gray_image[:h//2, w//2:],  # Top-right
                gray_image[h//2:, :w//2],  # Bottom-left
                gray_image[h//2:, w//2:]   # Bottom-right
            ]
            
            for i, quadrant in enumerate(quadrants):
                features[f'quadrant_{i}_mean'] = np.mean(quadrant)
                features[f'quadrant_{i}_std'] = np.std(quadrant)
            
            logger.info(f"Extracted {len(features)} features from MRI scan")
            return features
            
        except Exception as e:
            logger.error(f"Error extracting features: {e}")
            return {}
    
    def _calculate_skewness(self, data: np.ndarray) -> float:
        """Calculate skewness of the data"""
        mean = np.mean(data)
        std = np.std(data)
        if std == 0:
            return 0
        return np.mean(((data - mean) / std) ** 3)
    
    def _calculate_kurtosis(self, data: np.ndarray) -> float:
        """Calculate kurtosis of the data"""
        mean = np.mean(data)
        std = np.std(data)
        if std == 0:
            return 0
        return np.mean(((data - mean) / std) ** 4) - 3
    
    def predict_alzheimers_stage(self, image_path: str) -> Dict[str, Any]:
        """
        Predict Alzheimer's disease stage from MRI scan
        
        Args:
            image_path: Path to the MRI image file
            
        Returns:
            Dictionary containing prediction results and analysis
        """
        try:
            # Preprocess the image
            processed_image = self.preprocess_mri_scan(image_path)
            if processed_image is None:
                return {'error': 'Failed to preprocess image'}
            
            # Extract features
            features = self.extract_features(processed_image[0])
            
            # Make prediction
            if self.model is None:
                return {'error': 'Model not loaded'}
            
            predictions = self.model.predict(processed_image)
            
            # Get predicted class and confidence
            predicted_class = np.argmax(predictions[0])
            confidence = np.max(predictions[0])
            
            # Create confidence scores dictionary
            confidence_scores = {
                self.class_names[i]: float(predictions[0][i]) 
                for i in range(len(self.class_names))
            }
            
            # Create detailed analysis
            analysis = {
                'predicted_stage': self.class_names[predicted_class],
                'confidence': float(confidence),
                'confidence_scores': confidence_scores,
                'features': features,
                'model_used': 'CNN_Alzheimer_Detection_v1.0',
                'image_size': processed_image.shape[1:3],
                'prediction_timestamp': datetime.now().isoformat(),
                'severity_level': self._get_severity_level(predicted_class, confidence),
                'recommendations': self._get_recommendations(predicted_class, confidence)
            }
            
            logger.info(f"Prediction completed: {analysis['predicted_stage']} "
                       f"(confidence: {analysis['confidence']:.3f})")
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error in prediction: {e}")
            return {'error': f'Prediction failed: {str(e)}'}
    
    def _get_severity_level(self, predicted_class: int, confidence: float) -> str:
        """Get severity level based on prediction"""
        severity_levels = {
            0: "Normal",
            1: "Mild",
            2: "Moderate", 
            3: "Severe"
        }
        
        base_severity = severity_levels.get(predicted_class, "Unknown")
        
        if confidence < 0.6:
            return f"{base_severity} (Low Confidence)"
        elif confidence < 0.8:
            return f"{base_severity} (Medium Confidence)"
        else:
            return f"{base_severity} (High Confidence)"
    
    def _get_recommendations(self, predicted_class: int, confidence: float) -> List[str]:
        """Get recommendations based on prediction"""
        recommendations = []
        
        if predicted_class == 0:  # NonDemented
            recommendations = [
                "Continue regular health monitoring",
                "Maintain healthy lifestyle habits",
                "Schedule annual check-ups"
            ]
        elif predicted_class == 1:  # VeryMildDemented
            recommendations = [
                "Consult with a neurologist",
                "Consider cognitive assessment",
                "Monitor for symptom progression",
                "Implement memory exercises"
            ]
        elif predicted_class == 2:  # MildDemented
            recommendations = [
                "Immediate neurological consultation required",
                "Consider medication options",
                "Implement safety measures",
                "Family support planning recommended"
            ]
        elif predicted_class == 3:  # ModerateDemented
            recommendations = [
                "Urgent medical attention required",
                "Consider specialized care facilities",
                "Implement comprehensive safety measures",
                "Family and caregiver support essential"
            ]
        
        if confidence < 0.7:
            recommendations.append("Consider additional diagnostic tests for confirmation")
        
        return recommendations
    
    def create_analysis_visualization(self, image_path: str, analysis: Dict[str, Any], 
                                    save_path: str = None) -> str:
        """
        Create comprehensive visualization of the analysis
        
        Args:
            image_path: Path to the original image
            analysis: Analysis results dictionary
            save_path: Path to save the visualization
            
        Returns:
            Path to the saved visualization
        """
        try:
            # Create figure with subplots
            fig, axes = plt.subplots(2, 3, figsize=(18, 12))
            fig.suptitle('MRI Scan Analysis - Alzheimer\'s Disease Detection', 
                        fontsize=16, fontweight='bold')
            
            # Load and display original image
            original_image = cv2.imread(image_path)
            original_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
            axes[0, 0].imshow(original_image)
            axes[0, 0].set_title('Original MRI Scan')
            axes[0, 0].axis('off')
            
            # Display preprocessed image
            processed_image = self.preprocess_mri_scan(image_path)
            if processed_image is not None:
                axes[0, 1].imshow(processed_image[0])
                axes[0, 1].set_title('Preprocessed Image')
                axes[0, 1].axis('off')
            
            # Confidence scores bar chart
            stages = list(analysis['confidence_scores'].keys())
            scores = list(analysis['confidence_scores'].values())
            colors = ['#3498db', '#e74c3c', '#f39c12', '#27ae60']
            
            bars = axes[0, 2].bar(stages, scores, color=colors)
            axes[0, 2].set_title('Confidence Scores by Stage')
            axes[0, 2].set_ylabel('Confidence Score')
            axes[0, 2].tick_params(axis='x', rotation=45)
            
            # Add value labels on bars
            for bar, score in zip(bars, scores):
                height = bar.get_height()
                axes[0, 2].text(bar.get_x() + bar.get_width()/2., height + 0.01,
                               f'{score:.3f}', ha='center', va='bottom')
            
            # Feature analysis
            if 'features' in analysis:
                feature_names = list(analysis['features'].keys())[:8]  # Show first 8 features
                feature_values = list(analysis['features'].values())[:8]
                
                axes[1, 0].barh(feature_names, feature_values)
                axes[1, 0].set_title('Key Features Analysis')
                axes[1, 0].set_xlabel('Feature Value')
            
            # Prediction summary
            summary_text = f"""
Predicted Stage: {analysis['predicted_stage']}
Confidence: {analysis['confidence']:.3f}
Severity Level: {analysis['severity_level']}
Image Size: {analysis['image_size'][0]}x{analysis['image_size'][1]}
Model: {analysis['model_used']}
            """
            
            axes[1, 1].text(0.1, 0.5, summary_text, transform=axes[1, 1].transAxes,
                           fontsize=12, verticalalignment='center',
                           bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue"))
            axes[1, 1].set_title('Prediction Summary')
            axes[1, 1].axis('off')
            
            # Recommendations
            if 'recommendations' in analysis:
                rec_text = '\n'.join([f"• {rec}" for rec in analysis['recommendations']])
                axes[1, 2].text(0.1, 0.5, rec_text, transform=axes[1, 2].transAxes,
                               fontsize=10, verticalalignment='center',
                               bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgreen"))
                axes[1, 2].set_title('Recommendations')
                axes[1, 2].axis('off')
            
            plt.tight_layout()
            
            # Save visualization
            if save_path is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = f"mri_analysis_{timestamp}.png"
            
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"Analysis visualization saved to: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"Error creating visualization: {e}")
            return ""
    
    def batch_process(self, image_paths: List[str]) -> List[Dict[str, Any]]:
        """
        Process multiple MRI scans in batch
        
        Args:
            image_paths: List of image file paths
            
        Returns:
            List of analysis results
        """
        results = []
        
        for i, image_path in enumerate(image_paths):
            logger.info(f"Processing image {i+1}/{len(image_paths)}: {image_path}")
            
            try:
                result = self.predict_alzheimers_stage(image_path)
                result['image_path'] = image_path
                results.append(result)
                
            except Exception as e:
                logger.error(f"Error processing {image_path}: {e}")
                results.append({'error': f'Failed to process {image_path}: {str(e)}'})
        
        return results
    
    def generate_report(self, analysis: Dict[str, Any], output_path: str = None) -> str:
        """
        Generate a detailed analysis report
        
        Args:
            analysis: Analysis results dictionary
            output_path: Path to save the report
            
        Returns:
            Path to the saved report
        """
        try:
            if output_path is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = f"alzheimers_analysis_report_{timestamp}.json"
            
            # Create comprehensive report
            report = {
                'report_metadata': {
                    'generated_at': datetime.now().isoformat(),
                    'model_version': analysis.get('model_used', 'Unknown'),
                    'processor_version': '1.0.0'
                },
                'prediction_results': {
                    'predicted_stage': analysis.get('predicted_stage'),
                    'confidence': analysis.get('confidence'),
                    'severity_level': analysis.get('severity_level'),
                    'confidence_scores': analysis.get('confidence_scores', {})
                },
                'image_analysis': {
                    'image_size': analysis.get('image_size'),
                    'features_extracted': len(analysis.get('features', {})),
                    'feature_summary': analysis.get('features', {})
                },
                'recommendations': analysis.get('recommendations', []),
                'medical_disclaimer': {
                    'warning': 'This analysis is for research purposes only',
                    'recommendation': 'Always consult with qualified medical professionals'
                }
            }
            
            # Save report
            with open(output_path, 'w') as f:
                json.dump(report, f, indent=2)
            
            logger.info(f"Analysis report saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            return ""

def main():
    """Example usage of the MRI processor"""
    print("🧠 MRI Scan Processor for Alzheimer's Disease Detection")
    print("=" * 60)
    
    # Initialize processor
    processor = MRIScanProcessor()
    
    # Example usage
    print("\n📋 Usage Example:")
    print("processor = MRIScanProcessor()")
    print("analysis = processor.predict_alzheimers_stage('path/to/mri_scan.jpg')")
    print("processor.create_analysis_visualization('path/to/mri_scan.jpg', analysis)")
    print("processor.generate_report(analysis)")
    
    print("\n✅ MRI Processor ready for use!")

if __name__ == "__main__":
    main()
