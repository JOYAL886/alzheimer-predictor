#!/usr/bin/env python3
"""
Health Lab Backend Test Script
This script tests the backend functionality and API endpoints.
"""

import requests
import json
import time
import os
from datetime import datetime

class HealthLabTester:
    def __init__(self, base_url="http://localhost:5000"):
        self.base_url = base_url
        self.session = requests.Session()
        
    def test_health_endpoint(self):
        """Test the health check endpoint"""
        print("🔍 Testing health endpoint...")
        try:
            response = self.session.get(f"{self.base_url}/api/health", timeout=10)
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Health check passed: {data}")
                return True
            else:
                print(f"❌ Health check failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Health check error: {e}")
            return False
    
    def test_stats_endpoint(self):
        """Test the statistics endpoint"""
        print("📊 Testing statistics endpoint...")
        try:
            response = self.session.get(f"{self.base_url}/api/stats", timeout=10)
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Statistics retrieved: {data}")
                return True
            else:
                print(f"❌ Statistics failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Statistics error: {e}")
            return False
    
    def test_home_page(self):
        """Test the home page"""
        print("🏠 Testing home page...")
        try:
            response = self.session.get(f"{self.base_url}/", timeout=10)
            if response.status_code == 200:
                print("✅ Home page accessible")
                return True
            else:
                print(f"❌ Home page failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Home page error: {e}")
            return False
    
    def test_upload_page(self):
        """Test the upload page"""
        print("📤 Testing upload page...")
        try:
            response = self.session.get(f"{self.base_url}/upload", timeout=10)
            if response.status_code == 200:
                print("✅ Upload page accessible")
                return True
            else:
                print(f"❌ Upload page failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ Upload page error: {e}")
            return False
    
    def test_about_page(self):
        """Test the about page"""
        print("ℹ️ Testing about page...")
        try:
            response = self.session.get(f"{self.base_url}/about", timeout=10)
            if response.status_code == 200:
                print("✅ About page accessible")
                return True
            else:
                print(f"❌ About page failed: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ About page error: {e}")
            return False
    
    def test_prediction_endpoint(self, test_image_path=None):
        """Test the prediction endpoint"""
        print("🧠 Testing prediction endpoint...")
        
        # Create a simple test image if none provided
        if not test_image_path or not os.path.exists(test_image_path):
            print("📝 Creating test image...")
            test_image_path = self.create_test_image()
        
        if not test_image_path:
            print("❌ Could not create test image")
            return False
        
        try:
            with open(test_image_path, 'rb') as f:
                files = {'image': f}
                response = self.session.post(f"{self.base_url}/predict", files=files, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Prediction successful: {data}")
                return True
            else:
                print(f"❌ Prediction failed: {response.status_code}")
                print(f"Response: {response.text}")
                return False
        except Exception as e:
            print(f"❌ Prediction error: {e}")
            return False
    
    def create_test_image(self):
        """Create a simple test image for testing"""
        try:
            from PIL import Image, ImageDraw
            import numpy as np
            
            # Create a simple test image
            img = Image.new('RGB', (224, 224), color='white')
            draw = ImageDraw.Draw(img)
            
            # Draw some simple shapes to simulate brain scan
            draw.ellipse([50, 50, 174, 174], outline='gray', width=3)
            draw.rectangle([80, 80, 144, 144], outline='black', width=2)
            draw.line([100, 100, 124, 124], fill='red', width=2)
            
            # Save the test image
            test_image_path = "test_mri_scan.png"
            img.save(test_image_path)
            print(f"✅ Test image created: {test_image_path}")
            return test_image_path
            
        except ImportError:
            print("❌ PIL not available, cannot create test image")
            return None
        except Exception as e:
            print(f"❌ Error creating test image: {e}")
            return None
    
    def run_all_tests(self):
        """Run all tests"""
        print("🚀 Starting Health Lab Backend Tests")
        print("=" * 50)
        
        tests = [
            ("Health Check", self.test_health_endpoint),
            ("Statistics", self.test_stats_endpoint),
            ("Home Page", self.test_home_page),
            ("Upload Page", self.test_upload_page),
            ("About Page", self.test_about_page),
            ("Prediction", self.test_prediction_endpoint)
        ]
        
        results = []
        for test_name, test_func in tests:
            print(f"\n{'='*20} {test_name} {'='*20}")
            start_time = time.time()
            success = test_func()
            end_time = time.time()
            
            results.append({
                'test': test_name,
                'success': success,
                'duration': end_time - start_time
            })
            
            if success:
                print(f"✅ {test_name} passed in {end_time - start_time:.2f}s")
            else:
                print(f"❌ {test_name} failed in {end_time - start_time:.2f}s")
        
        # Print summary
        print("\n" + "="*50)
        print("📋 TEST SUMMARY")
        print("="*50)
        
        passed = sum(1 for r in results if r['success'])
        total = len(results)
        
        for result in results:
            status = "✅ PASS" if result['success'] else "❌ FAIL"
            print(f"{status} {result['test']} ({result['duration']:.2f}s)")
        
        print(f"\nOverall: {passed}/{total} tests passed")
        
        if passed == total:
            print("🎉 All tests passed! Backend is working correctly.")
        else:
            print("⚠️ Some tests failed. Please check the server logs.")
        
        return passed == total

def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Health Lab Backend Tester')
    parser.add_argument('--url', default='http://localhost:5000', 
                       help='Base URL of the server (default: http://localhost:5000)')
    parser.add_argument('--test-image', help='Path to test image file')
    
    args = parser.parse_args()
    
    # Create tester instance
    tester = HealthLabTester(args.url)
    
    # Run tests
    success = tester.run_all_tests()
    
    # Exit with appropriate code
    exit(0 if success else 1)

if __name__ == "__main__":
    main()
