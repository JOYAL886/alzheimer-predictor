# Health Lab - Alzheimer's Disease Detection System

A comprehensive web-based system for detecting Alzheimer's disease from MRI scans using deep learning and computer vision techniques.

## 🧠 Overview

Health Lab is an AI-powered platform that assists doctors in diagnosing Alzheimer's disease by analyzing MRI brain scans. The system provides:

- **Automated MRI Analysis**: Upload and analyze brain scans for Alzheimer's detection
- **Multi-Stage Classification**: Classify scans into 4 stages (Non-Demented, Very Mild, Mild, Moderate)
- **Confidence Scoring**: Provide detailed confidence scores for each prediction
- **Visual Analysis**: Generate visualizations of analysis results
- **Web Interface**: User-friendly web interface for easy interaction

## 🏗️ Architecture

### Frontend
- **HTML/CSS/JavaScript**: Modern, responsive web interface
- **Interactive UI**: Dynamic upload interface with progress tracking
- **Real-time Feedback**: Live status updates and result display

### Backend
- **Flask**: Python web framework for API endpoints
- **TensorFlow/Keras**: Deep learning model for image classification
- **OpenCV**: Image processing and preprocessing
- **RESTful API**: Clean API design for frontend integration

### AI Model
- **CNN Architecture**: Custom convolutional neural network
- **Transfer Learning**: Pre-trained model adaptation
- **Data Augmentation**: Enhanced training with image transformations
- **Multi-class Classification**: 4-stage Alzheimer's classification

## 📁 Project Structure

```
PROJECT/
├── app.py                 # Main Flask application
├── train_model.py         # Model training script
├── start_server.py        # Server startup script
├── requirements.txt       # Python dependencies
├── README.md             # Project documentation
├── index.html            # Home page
├── about.html            # About page
├── upload.html           # Upload interface
├── assets/               # Static assets
│   └── images/          # Images and logos
├── styles/               # CSS stylesheets
│   └── styles.css       # Main stylesheet
├── scripts/              # JavaScript files
│   ├── script.js        # General scripts
│   └── upload.js        # Upload functionality
├── uploads/              # Uploaded files storage
├── results/              # Analysis results storage
├── models/               # Trained model files
├── logs/                 # Application logs
├── data/                 # Training data (not included)
└── plots/                # Training visualizations
```

## 🚀 Quick Start

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Modern web browser

### Installation

1. **Clone or download the project**
   ```bash
   # If using git
   git clone <repository-url>
   cd PROJECT
   ```

2. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the server**
   ```bash
   python start_server.py
   ```

4. **Access the application**
   - Open your web browser
   - Navigate to: `http://localhost:5000`
   - The application will be ready to use!

### Alternative Startup Methods

```bash
# Check dependencies only
python start_server.py --check-deps

# Start with custom host/port
python start_server.py --host 127.0.0.1 --port 8080

# Start in debug mode
python start_server.py --debug

# Check server status
python start_server.py --status

# Get server information
python start_server.py --info
```

## 🎯 Usage

### For Users (Doctors/Medical Professionals)

1. **Access the Application**
   - Open the web interface at `http://localhost:5000`
   - Navigate to the "Upload" page

2. **Upload MRI Scan**
   - Click "Upload MRI Scan" button
   - Select your MRI image file (JPG, PNG, TIFF supported)
   - Wait for analysis to complete

3. **Review Results**
   - View predicted Alzheimer's stage
   - Check confidence scores for all stages
   - Review detailed analysis report

### For Developers

#### API Endpoints

- `GET /` - Home page
- `GET /about` - About page
- `GET /upload` - Upload interface
- `POST /predict` - MRI analysis endpoint
- `GET /api/health` - Health check
- `GET /api/stats` - Server statistics

#### Model Training

```bash
# Train a new model
python train_model.py
```

The training script will:
- Load and preprocess training data
- Create and train the CNN model
- Generate evaluation metrics
- Save trained model and visualizations

## 🔧 Configuration

### Environment Variables

- `FLASK_ENV`: Set to 'development' or 'production'
- `FLASK_DEBUG`: Enable/disable debug mode (1/0)

### Model Configuration

Edit `app.py` to modify:
- Model architecture
- Image preprocessing parameters
- Classification thresholds
- File upload limits

### Training Configuration

Edit `train_model.py` to modify:
- Training parameters (epochs, batch size)
- Data augmentation settings
- Model architecture
- Evaluation metrics

## 📊 Model Performance

The system provides comprehensive evaluation metrics:

- **Accuracy**: Overall classification accuracy
- **Precision**: Precision for each Alzheimer's stage
- **Recall**: Recall for each Alzheimer's stage
- **Confusion Matrix**: Detailed classification results
- **Confidence Scores**: Probability scores for each stage

## 🔒 Security & Privacy

- **File Validation**: Strict file type and size validation
- **Secure Uploads**: Safe file handling and storage
- **Data Privacy**: No patient data is stored permanently
- **Error Handling**: Comprehensive error management

## 🛠️ Development

### Adding New Features

1. **Backend Changes**
   - Modify `app.py` for new API endpoints
   - Update model in `train_model.py`
   - Add new dependencies to `requirements.txt`

2. **Frontend Changes**
   - Edit HTML files for UI changes
   - Update CSS in `styles/styles.css`
   - Modify JavaScript in `scripts/` directory

3. **Model Improvements**
   - Enhance architecture in `train_model.py`
   - Add new preprocessing steps
   - Implement ensemble methods

### Testing

```bash
# Test server health
curl http://localhost:5000/api/health

# Test prediction endpoint
curl -X POST -F "image=@test_image.jpg" http://localhost:5000/predict
```

## 📈 Monitoring

### Logs
- Application logs: `logs/server.log`
- Training logs: `logs/training_results.json`

### Metrics
- Server statistics: `GET /api/stats`
- Health status: `GET /api/health`

## 🐛 Troubleshooting

### Common Issues

1. **Server won't start**
   - Check Python version (3.8+ required)
   - Install missing dependencies: `pip install -r requirements.txt`
   - Check port availability

2. **Model loading fails**
   - Ensure TensorFlow is installed correctly
   - Check available memory
   - Verify model file exists

3. **Upload fails**
   - Check file format (JPG, PNG, TIFF only)
   - Verify file size (max 16MB)
   - Ensure upload directory exists

4. **Prediction errors**
   - Verify image format and quality
   - Check model is loaded properly
   - Review server logs for details

### Debug Mode

```bash
# Start with debug logging
python start_server.py --debug
```

## 📚 API Documentation

### Prediction Endpoint

**POST** `/predict`

Upload an MRI image for Alzheimer's analysis.

**Request:**
- Content-Type: `multipart/form-data`
- Body: `image` (file)

**Response:**
```json
{
  "predicted_stage": "NonDemented",
  "confidence": 0.85,
  "confidence_scores": {
    "NonDemented": 0.85,
    "VeryMildDemented": 0.10,
    "MildDemented": 0.03,
    "ModerateDemented": 0.02
  },
  "model_used": "CNN_Alzheimer_Detection_v1.0",
  "image_size": [224, 224],
  "upload_timestamp": "2024-01-15T10:30:00",
  "original_filename": "patient_scan.jpg"
}
```

### Health Check

**GET** `/api/health`

Check server and model status.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00",
  "model_loaded": true
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Medical imaging research community
- TensorFlow and Keras developers
- Flask web framework team
- OpenCV contributors

## 📞 Support

For support and questions:
- Check the troubleshooting section
- Review server logs
- Create an issue in the repository

---

**⚠️ Medical Disclaimer**: This system is designed to assist medical professionals and should not be used as a substitute for professional medical diagnosis. Always consult with qualified healthcare providers for medical decisions. 