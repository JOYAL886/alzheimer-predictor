import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
import cv2
import logging
from datetime import datetime
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AlzheimerModelTrainer:
    def __init__(self, data_path='data', model_save_path='models'):
        """
        Initialize the Alzheimer's disease model trainer
        
        Args:
            data_path: Path to the training data directory
            model_save_path: Path to save trained models
        """
        self.data_path = data_path
        self.model_save_path = model_save_path
        self.class_names = ['NonDemented', 'VeryMildDemented', 'MildDemented', 'ModerateDemented']
        self.img_size = (224, 224)
        self.batch_size = 32
        self.epochs = 50
        
        # Create directories
        os.makedirs(model_save_path, exist_ok=True)
        os.makedirs('logs', exist_ok=True)
        os.makedirs('plots', exist_ok=True)
        
        # Initialize data generators
        self.train_datagen = ImageDataGenerator(
            rescale=1./255,
            rotation_range=20,
            width_shift_range=0.2,
            height_shift_range=0.2,
            shear_range=0.2,
            zoom_range=0.2,
            horizontal_flip=True,
            fill_mode='nearest',
            validation_split=0.2
        )
        
        self.test_datagen = ImageDataGenerator(rescale=1./255)
        
    def load_and_preprocess_data(self):
        """Load and preprocess the training data"""
        logger.info("Loading and preprocessing data...")
        
        try:
            # Load training data
            train_generator = self.train_datagen.flow_from_directory(
                os.path.join(self.data_path, 'train'),
                target_size=self.img_size,
                batch_size=self.batch_size,
                class_mode='categorical',
                subset='training'
            )
            
            # Load validation data
            validation_generator = self.train_datagen.flow_from_directory(
                os.path.join(self.data_path, 'train'),
                target_size=self.img_size,
                batch_size=self.batch_size,
                class_mode='categorical',
                subset='validation'
            )
            
            # Load test data
            test_generator = self.test_datagen.flow_from_directory(
                os.path.join(self.data_path, 'test'),
                target_size=self.img_size,
                batch_size=self.batch_size,
                class_mode='categorical',
                shuffle=False
            )
            
            logger.info(f"Training samples: {train_generator.samples}")
            logger.info(f"Validation samples: {validation_generator.samples}")
            logger.info(f"Test samples: {test_generator.samples}")
            
            return train_generator, validation_generator, test_generator
            
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            return None, None, None
    
    def create_model(self):
        """Create the CNN model architecture"""
        logger.info("Creating model architecture...")
        
        model = models.Sequential([
            # First Convolutional Block
            layers.Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)),
            layers.BatchNormalization(),
            layers.Conv2D(32, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Second Convolutional Block
            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Third Convolutional Block
            layers.Conv2D(128, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.Conv2D(128, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Fourth Convolutional Block
            layers.Conv2D(256, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.Conv2D(256, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Flatten and Dense Layers
            layers.Flatten(),
            layers.Dense(512, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.5),
            layers.Dense(256, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.5),
            layers.Dense(len(self.class_names), activation='softmax')
        ])
        
        # Compile the model
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )
        
        logger.info("Model architecture created successfully")
        return model
    
    def create_callbacks(self):
        """Create training callbacks"""
        callbacks = [
            # Early stopping to prevent overfitting
            EarlyStopping(
                monitor='val_loss',
                patience=10,
                restore_best_weights=True,
                verbose=1
            ),
            
            # Reduce learning rate when plateau is reached
            ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=5,
                min_lr=1e-7,
                verbose=1
            ),
            
            # Save best model
            ModelCheckpoint(
                filepath=os.path.join(self.model_save_path, 'best_model.h5'),
                monitor='val_accuracy',
                save_best_only=True,
                verbose=1
            )
        ]
        
        return callbacks
    
    def train_model(self, model, train_generator, validation_generator):
        """Train the model"""
        logger.info("Starting model training...")
        
        callbacks = self.create_callbacks()
        
        # Train the model
        history = model.fit(
            train_generator,
            epochs=self.epochs,
            validation_data=validation_generator,
            callbacks=callbacks,
            verbose=1
        )
        
        logger.info("Training completed successfully")
        return history
    
    def evaluate_model(self, model, test_generator):
        """Evaluate the trained model"""
        logger.info("Evaluating model...")
        
        # Get predictions
        predictions = model.predict(test_generator)
        predicted_classes = np.argmax(predictions, axis=1)
        true_classes = test_generator.classes
        
        # Calculate metrics
        test_loss, test_accuracy, test_precision, test_recall = model.evaluate(test_generator)
        
        # Generate classification report
        class_report = classification_report(
            true_classes, 
            predicted_classes, 
            target_names=self.class_names,
            output_dict=True
        )
        
        # Generate confusion matrix
        cm = confusion_matrix(true_classes, predicted_classes)
        
        logger.info(f"Test Accuracy: {test_accuracy:.4f}")
        logger.info(f"Test Precision: {test_precision:.4f}")
        logger.info(f"Test Recall: {test_recall:.4f}")
        
        return {
            'test_accuracy': test_accuracy,
            'test_precision': test_precision,
            'test_recall': test_recall,
            'classification_report': class_report,
            'confusion_matrix': cm.tolist(),
            'predictions': predictions.tolist(),
            'true_classes': true_classes.tolist(),
            'predicted_classes': predicted_classes.tolist()
        }
    
    def plot_training_history(self, history):
        """Plot training history"""
        logger.info("Creating training history plots...")
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Plot accuracy
        axes[0, 0].plot(history.history['accuracy'], label='Training Accuracy')
        axes[0, 0].plot(history.history['val_accuracy'], label='Validation Accuracy')
        axes[0, 0].set_title('Model Accuracy')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Accuracy')
        axes[0, 0].legend()
        axes[0, 0].grid(True)
        
        # Plot loss
        axes[0, 1].plot(history.history['loss'], label='Training Loss')
        axes[0, 1].plot(history.history['val_loss'], label='Validation Loss')
        axes[0, 1].set_title('Model Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)
        
        # Plot precision
        axes[1, 0].plot(history.history['precision'], label='Training Precision')
        axes[1, 0].plot(history.history['val_precision'], label='Validation Precision')
        axes[1, 0].set_title('Model Precision')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Precision')
        axes[1, 0].legend()
        axes[1, 0].grid(True)
        
        # Plot recall
        axes[1, 1].plot(history.history['recall'], label='Training Recall')
        axes[1, 1].plot(history.history['val_recall'], label='Validation Recall')
        axes[1, 1].set_title('Model Recall')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('Recall')
        axes[1, 1].legend()
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        plt.savefig('plots/training_history.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info("Training history plots saved to plots/training_history.png")
    
    def plot_confusion_matrix(self, confusion_matrix):
        """Plot confusion matrix"""
        logger.info("Creating confusion matrix plot...")
        
        plt.figure(figsize=(10, 8))
        sns.heatmap(
            confusion_matrix, 
            annot=True, 
            fmt='d', 
            cmap='Blues',
            xticklabels=self.class_names,
            yticklabels=self.class_names
        )
        plt.title('Confusion Matrix')
        plt.xlabel('Predicted')
        plt.ylabel('Actual')
        plt.tight_layout()
        plt.savefig('plots/confusion_matrix.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info("Confusion matrix plot saved to plots/confusion_matrix.png")
    
    def save_results(self, evaluation_results, history):
        """Save training and evaluation results"""
        logger.info("Saving results...")
        
        # Save evaluation results
        results = {
            'timestamp': datetime.now().isoformat(),
            'model_architecture': 'CNN_Alzheimer_Detection_v1.0',
            'class_names': self.class_names,
            'img_size': self.img_size,
            'batch_size': self.batch_size,
            'epochs_trained': len(history.history['loss']),
            'evaluation_results': evaluation_results,
            'training_history': {
                'accuracy': history.history['accuracy'],
                'val_accuracy': history.history['val_accuracy'],
                'loss': history.history['loss'],
                'val_loss': history.history['val_loss'],
                'precision': history.history['precision'],
                'val_precision': history.history['val_precision'],
                'recall': history.history['recall'],
                'val_recall': history.history['val_recall']
            }
        }
        
        # Save to JSON file
        with open('logs/training_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info("Results saved to logs/training_results.json")
    
    def run_training_pipeline(self):
        """Run the complete training pipeline"""
        logger.info("Starting Alzheimer's disease model training pipeline...")
        
        try:
            # Load data
            train_generator, validation_generator, test_generator = self.load_and_preprocess_data()
            
            if train_generator is None:
                logger.error("Failed to load data. Please check your data directory structure.")
                return False
            
            # Create model
            model = self.create_model()
            
            # Train model
            history = self.train_model(model, train_generator, validation_generator)
            
            # Evaluate model
            evaluation_results = self.evaluate_model(model, test_generator)
            
            # Create plots
            self.plot_training_history(history)
            self.plot_confusion_matrix(evaluation_results['confusion_matrix'])
            
            # Save results
            self.save_results(evaluation_results, history)
            
            # Save final model
            model.save(os.path.join(self.model_save_path, 'final_model.h5'))
            logger.info(f"Final model saved to {self.model_save_path}/final_model.h5")
            
            logger.info("Training pipeline completed successfully!")
            return True
            
        except Exception as e:
            logger.error(f"Error in training pipeline: {e}")
            return False

def main():
    """Main function to run the training pipeline"""
    print("=" * 60)
    print("Alzheimer's Disease Detection Model Training")
    print("=" * 60)
    
    # Initialize trainer
    trainer = AlzheimerModelTrainer()
    
    # Run training pipeline
    success = trainer.run_training_pipeline()
    
    if success:
        print("\n✅ Training completed successfully!")
        print("📁 Check the following directories for results:")
        print("   - models/ : Trained model files")
        print("   - plots/ : Training plots and visualizations")
        print("   - logs/ : Training logs and results")
    else:
        print("\n❌ Training failed. Please check the logs for details.")
    
    print("=" * 60)

if __name__ == "__main__":
    main() 