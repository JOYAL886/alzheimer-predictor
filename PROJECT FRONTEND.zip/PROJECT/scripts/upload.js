document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('mriFile');
    const fileLabel = document.querySelector('.file-label');
    const fileHint = document.querySelector('.file-hint');
    const uploadForm = document.getElementById('uploadForm');
    const uploadBtn = document.querySelector('.upload-btn');

    // Handle file selection
    fileInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            const fileName = this.files[0].name;
            fileHint.textContent = fileName;
            fileLabel.style.borderColor = '#19c2a0';
            fileLabel.style.backgroundColor = '#f0f9ff';
            uploadBtn.disabled = false;
        } else {
            fileHint.textContent = 'No file chosen';
            fileLabel.style.borderColor = '#ddd';
            fileLabel.style.backgroundColor = '#fff';
            uploadBtn.disabled = true;
        }
    });

    // Handle form submission
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!fileInput.files || !fileInput.files[0]) {
            alert('Please select a file first.');
            return;
        }

        // Show loading state
        uploadBtn.textContent = 'UPLOADING...';
        uploadBtn.disabled = true;

        // Simulate upload process (replace with actual API call)
        setTimeout(() => {
            alert('File uploaded successfully! This is a demo. In a real application, this would send the file to your AI model for analysis.');
            
            // Reset form
            uploadForm.reset();
            fileHint.textContent = 'No file chosen';
            fileLabel.style.borderColor = '#ddd';
            fileLabel.style.backgroundColor = '#fff';
            uploadBtn.textContent = 'UPLOAD MRI SCAN';
            uploadBtn.disabled = true;
        }, 2000);
    });

    // Drag and drop functionality
    fileLabel.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = '#19c2a0';
        this.style.backgroundColor = '#f0f9ff';
    });

    fileLabel.addEventListener('dragleave', function(e) {
        e.preventDefault();
        if (!this.contains(e.relatedTarget)) {
            this.style.borderColor = '#ddd';
            this.style.backgroundColor = '#fff';
        }
    });

    fileLabel.addEventListener('drop', function(e) {
        e.preventDefault();
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            fileInput.dispatchEvent(new Event('change'));
        }
    });
}); 