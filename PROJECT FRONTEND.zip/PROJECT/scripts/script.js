const mriImage = document.getElementById('mriImage');
const submitBtn = document.getElementById('submitBtn');
const mriForm = document.getElementById('mriForm');
const resultBox = document.getElementById('resultBox');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const previewText = document.getElementById('previewText');

mriImage.addEventListener('change', function() {
    if (mriImage.files && mriImage.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewImg.style.display = 'block';
            previewText.style.display = 'none';
        };
        reader.readAsDataURL(mriImage.files[0]);
        submitBtn.disabled = false;
    } else {
        previewImg.src = '';
        previewImg.style.display = 'none';
        previewText.style.display = 'block';
        submitBtn.disabled = true;
    }
    resultBox.style.display = 'none';
});

mriForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    submitBtn.disabled = true;
    resultBox.style.display = 'block';
    resultBox.textContent = 'Analyzing...';

    // Placeholder for actual API call
    // const formData = new FormData();
    // formData.append('mriImage', mriImage.files[0]);
    // const response = await fetch('/api/predict', { method: 'POST', body: formData });
    // const data = await response.json();
    // resultBox.textContent = 'Prediction: ' + data.prediction;

    setTimeout(() => {
        // Simulated result for demo
        const results = [
            "Healthy",
            "Early Stage Alzheimer's",
            "Moderate Alzheimer's",
            "Advanced Alzheimer's"
        ];
        const randomResult = results[Math.floor(Math.random() * results.length)];
        resultBox.textContent = 'Prediction: ' + randomResult;
        submitBtn.disabled = false;
    }, 1800);
}); 