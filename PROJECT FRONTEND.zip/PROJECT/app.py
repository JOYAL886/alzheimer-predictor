from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import os
import cv2
import numpy as np
from PIL import Image
import io
import base64
import json
import logging
from datetime import datetime
import uuid
from werkzeug.utils import secure_filename
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
import pandas as pd
from mri_processor import MRIScanProcessor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['RESULTS_FOLDER'] = 'results'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'tiff', 'bmp'}

# Create directories if they don't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['RESULTS_FOLDER'], exist_ok=True)

# Global variables for model and preprocessing
model = None
scaler = StandardScaler()
class_names = ['NonDemented', 'VeryMildDemented', 'MildDemented', 'ModerateDemented']
mri_processor = None

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def load_model():
    """Load the pre-trained model and initialize MRI processor"""
    global model, mri_processor
    try:
        # Initialize MRI processor
        mri_processor = MRIScanProcessor()
        logger.info("MRI processor initialized successfully")
        
        # For now, we'll create a simple model structure
        # In production, you would load your actual trained model
        model = create_simple_model()
        logger.info("Model loaded successfully")
        return True
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        return False

def create_simple_model():
    """Create a simple CNN model for demonstration"""
    model = keras.Sequential([
        keras.layers.Conv2D(32, 3, activation='relu', input_shape=(224, 224, 3)),
        keras.layers.MaxPooling2D(),
        keras.layers.Conv2D(64, 3, activation='relu'),
        keras.layers.MaxPooling2D(),
        keras.layers.Conv2D(64, 3, activation='relu'),
        keras.layers.Flatten(),
        keras.layers.Dense(64, activation='relu'),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(4, activation='softmax')
    ])
    
    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model

def preprocess_image(image):
    """Preprocess image for model input"""
    try:
        # Convert to RGB if grayscale
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif image.shape[2] == 1:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        
        # Resize to 224x224
        image = cv2.resize(image, (224, 224))
        
        # Normalize pixel values
        image = image.astype(np.float32) / 255.0
        
        # Add batch dimension
        image = np.expand_dims(image, axis=0)
        
        return image
    except Exception as e:
        logger.error(f"Error preprocessing image: {e}")
        return None

def predict_alzheimer_stage(image_path):
    """Predict Alzheimer's disease stage from MRI image using MRI processor"""
    try:
        if mri_processor is None:
            logger.error("MRI processor not initialized")
            return None
        
        # Use MRI processor for comprehensive analysis
        analysis = mri_processor.predict_alzheimers_stage(image_path)
        
        if 'error' in analysis:
            logger.error(f"MRI processor error: {analysis['error']}")
            return None
        
        return analysis
        
    except Exception as e:
        logger.error(f"Error in prediction: {e}")
        return None

def save_uploaded_file(file):
    """Save uploaded file and return file path"""
    try:
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_id = str(uuid.uuid4())[:8]
        filename = f"{timestamp}_{unique_id}_{filename}"
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        logger.info(f"File saved: {filepath}")
        return filepath
    except Exception as e:
        logger.error(f"Error saving file: {e}")
        return None

def create_analysis_visualization(image, prediction_result):
    """Create visualization for the analysis results"""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Original image
        axes[0].imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        axes[0].set_title('Uploaded MRI Scan')
        axes[0].axis('off')
        
        # Confidence scores bar chart
        stages = list(prediction_result['confidence_scores'].keys())
        scores = list(prediction_result['confidence_scores'].values())
        
        colors = ['#3498db', '#e74c3c', '#f39c12', '#27ae60']
        bars = axes[1].bar(stages, scores, color=colors)
        axes[1].set_title('Confidence Scores by Stage')
        axes[1].set_ylabel('Confidence Score')
        axes[1].tick_params(axis='x', rotation=45)
        
        # Add value labels on bars
        for bar, score in zip(bars, scores):
            height = bar.get_height()
            axes[1].text(bar.get_x() + bar.get_width()/2., height + 0.01,
                        f'{score:.3f}', ha='center', va='bottom')
        
        plt.tight_layout()
        
        # Save the visualization
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        viz_filename = f"analysis_{timestamp}.png"
        viz_path = os.path.join(app.config['RESULTS_FOLDER'], viz_filename)
        plt.savefig(viz_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return viz_filename
    except Exception as e:
        logger.error(f"Error creating visualization: {e}")
        return None

@app.route('/')
def index():
    """Serve the main page"""
    return send_from_directory('.', 'index.html')

@app.route('/about')
def about():
    """Serve the about page"""
    return send_from_directory('.', 'about.html')

@app.route('/upload')
def upload():
    """Serve the upload page"""
    return send_from_directory('.', 'upload.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Handle MRI scan upload and prediction"""
    try:
        # Check if file is present
        if 'image' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['image']
        
        # Check if file is selected
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Check file extension
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Please upload an image file.'}), 400
        
        # Save uploaded file
        filepath = save_uploaded_file(file)
        if filepath is None:
            return jsonify({'error': 'Error saving uploaded file'}), 500
        
        # Make prediction using MRI processor
        prediction_result = predict_alzheimer_stage(filepath)
        if prediction_result is None:
            return jsonify({'error': 'Error during prediction'}), 500
        
        # Create visualization using MRI processor
        viz_filename = mri_processor.create_analysis_visualization(filepath, prediction_result)
        if viz_filename:
            prediction_result['visualization'] = viz_filename
        
        # Add metadata
        prediction_result['upload_timestamp'] = datetime.now().isoformat()
        prediction_result['original_filename'] = file.filename
        
        logger.info(f"Prediction completed: {prediction_result['predicted_stage']} "
                   f"(confidence: {prediction_result['confidence']:.3f})")
        
        return jsonify(prediction_result)
        
    except Exception as e:
        logger.error(f"Error in predict endpoint: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/results/<filename>')
def get_result(filename):
    """Serve analysis result files"""
    return send_from_directory(app.config['RESULTS_FOLDER'], filename)

@app.route('/uploads/<filename>')
def get_upload(filename):
    """Serve uploaded files"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'model_loaded': model is not None
    })

@app.route('/api/stats')
def get_stats():
    """Get system statistics"""
    try:
        upload_count = len(os.listdir(app.config['UPLOAD_FOLDER']))
        result_count = len(os.listdir(app.config['RESULTS_FOLDER']))
        
        return jsonify({
            'uploads_processed': upload_count,
            'results_generated': result_count,
            'model_status': 'loaded' if model is not None else 'not_loaded',
            'server_uptime': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        return jsonify({'error': 'Error retrieving statistics'}), 500

@app.errorhandler(413)
def too_large(e):
    """Handle file too large error"""
    return jsonify({'error': 'File too large. Maximum size is 16MB.'}), 413

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(e):
    """Handle internal server errors"""
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Load model on startup
    if load_model():
        logger.info("Starting Health Lab Backend Server...")
        app.run(debug=True, host='0.0.0.0', port=5000)
    else:
        logger.error("Failed to load model. Server not started.") 