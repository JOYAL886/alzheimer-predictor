# MRI Processing Guide for Alzheimer's Disease Detection

## 🧠 Overview

This guide explains how to use the comprehensive MRI processing system for detecting and classifying Alzheimer's disease stages from brain MRI scans.

## 📋 Table of Contents

1. [System Architecture](#system-architecture)
2. [Installation & Setup](#installation--setup)
3. [Basic Usage](#basic-usage)
4. [Advanced Features](#advanced-features)
5. [API Integration](#api-integration)
6. [Model Training](#model-training)
7. [Troubleshooting](#troubleshooting)

## 🏗️ System Architecture

### Core Components

```
MRI Processing System
├── mri_processor.py          # Main processing module
├── app.py                    # Flask API integration
├── train_model.py            # Model training script
├── example_mri_analysis.py   # Usage examples
└── config.py                 # Configuration management
```

### Processing Pipeline

1. **Image Loading** → Load MRI scan from file
2. **Preprocessing** → Enhance and normalize image
3. **Feature Extraction** → Extract diagnostic features
4. **Model Prediction** → Classify Alzheimer's stage
5. **Analysis** → Generate detailed report
6. **Visualization** → Create analysis plots

## 🚀 Installation & Setup

### Prerequisites

```bash
# Install required packages
pip install -r requirements.txt
```

### Quick Start

```python
from mri_processor import MRIScanProcessor

# Initialize processor
processor = MRIScanProcessor()

# Analyze MRI scan
analysis = processor.predict_alzheimers_stage('path/to/mri_scan.jpg')
```

## 📖 Basic Usage

### 1. Single MRI Analysis

```python
from mri_processor import MRIScanProcessor

# Initialize the processor
processor = MRIScanProcessor()

# Analyze a single MRI scan
analysis = processor.predict_alzheimers_stage('mri_scan.jpg')

# Check results
print(f"Predicted Stage: {analysis['predicted_stage']}")
print(f"Confidence: {analysis['confidence']:.3f}")
print(f"Severity Level: {analysis['severity_level']}")

# View all confidence scores
for stage, score in analysis['confidence_scores'].items():
    print(f"{stage}: {score:.3f}")

# Get recommendations
for rec in analysis['recommendations']:
    print(f"• {rec}")
```

### 2. Batch Processing

```python
# Process multiple MRI scans
image_paths = ['scan1.jpg', 'scan2.jpg', 'scan3.jpg']
results = processor.batch_process(image_paths)

# Review batch results
for i, result in enumerate(results):
    if 'error' not in result:
        print(f"Scan {i+1}: {result['predicted_stage']} "
              f"(confidence: {result['confidence']:.3f})")
```

### 3. Feature Extraction

```python
# Extract features from MRI scan
processed_image = processor.preprocess_mri_scan('mri_scan.jpg')
features = processor.extract_features(processed_image[0])

# View extracted features
for feature_name, value in features.items():
    print(f"{feature_name}: {value:.4f}")
```

## 🔧 Advanced Features

### 1. Custom Model Loading

```python
# Load a custom trained model
processor = MRIScanProcessor(model_path='path/to/custom_model.h5')
```

### 2. Image Enhancement

```python
# Customize enhancement parameters
processor.contrast_factor = 1.5
processor.brightness_factor = 1.2
processor.sharpen_factor = 2.0

# Process with custom settings
analysis = processor.predict_alzheimers_stage('mri_scan.jpg')
```

### 3. Visualization Generation

```python
# Create comprehensive visualization
viz_path = processor.create_analysis_visualization(
    'mri_scan.jpg', 
    analysis,
    save_path='analysis_visualization.png'
)
```

### 4. Report Generation

```python
# Generate detailed analysis report
report_path = processor.generate_report(
    analysis,
    output_path='alzheimers_report.json'
)
```

## 🌐 API Integration

### Flask API Endpoint

The MRI processor is integrated into the Flask API:

```python
# POST /predict endpoint
@app.route('/predict', methods=['POST'])
def predict():
    # File upload handling
    file = request.files['image']
    
    # Save uploaded file
    filepath = save_uploaded_file(file)
    
    # Process with MRI processor
    prediction_result = predict_alzheimer_stage(filepath)
    
    # Return JSON response
    return jsonify(prediction_result)
```

### API Response Format

```json
{
  "predicted_stage": "MildDemented",
  "confidence": 0.85,
  "confidence_scores": {
    "NonDemented": 0.05,
    "VeryMildDemented": 0.08,
    "MildDemented": 0.85,
    "ModerateDemented": 0.02
  },
  "severity_level": "Moderate (High Confidence)",
  "recommendations": [
    "Immediate neurological consultation required",
    "Consider medication options",
    "Implement safety measures"
  ],
  "features": {
    "mean_intensity": 127.5,
    "texture_variance": 45.2,
    "edge_density": 0.15
  },
  "model_used": "CNN_Alzheimer_Detection_v1.0",
  "image_size": [224, 224],
  "prediction_timestamp": "2024-01-15T10:30:00"
}
```

## 🎯 Model Training

### Training Your Own Model

```python
from train_model import AlzheimerModelTrainer

# Initialize trainer
trainer = AlzheimerModelTrainer(
    data_path='path/to/training/data',
    model_save_path='models'
)

# Run training pipeline
success = trainer.run_training_pipeline()

if success:
    print("✅ Training completed successfully!")
```

### Data Organization

```
data/
├── train/
│   ├── NonDemented/
│   │   ├── image1.jpg
│   │   └── image2.jpg
│   ├── VeryMildDemented/
│   │   ├── image3.jpg
│   │   └── image4.jpg
│   ├── MildDemented/
│   │   └── ...
│   └── ModerateDemented/
│       └── ...
└── test/
    ├── NonDemented/
    ├── VeryMildDemented/
    ├── MildDemented/
    └── ModerateDemented/
```

## 🔍 Feature Analysis

### Extracted Features

The system extracts comprehensive features from MRI scans:

#### Statistical Features
- `mean_intensity`: Average pixel intensity
- `std_intensity`: Standard deviation of intensity
- `min_intensity`: Minimum pixel value
- `max_intensity`: Maximum pixel value

#### Histogram Features
- `histogram_peaks`: Number of histogram peaks
- `histogram_entropy`: Information entropy

#### Texture Features
- `texture_variance`: Image variance
- `texture_skewness`: Distribution skewness
- `texture_kurtosis`: Distribution kurtosis

#### Edge Features
- `edge_density`: Density of detected edges

#### Regional Features
- `quadrant_0_mean`: Top-left quadrant mean
- `quadrant_1_mean`: Top-right quadrant mean
- `quadrant_2_mean`: Bottom-left quadrant mean
- `quadrant_3_mean`: Bottom-right quadrant mean

## 📊 Classification Stages

### Alzheimer's Disease Stages

1. **NonDemented** (Normal)
   - No cognitive decline
   - Normal brain function
   - Confidence: High

2. **VeryMildDemented** (Early Stage)
   - Mild cognitive impairment
   - Early memory problems
   - Confidence: Medium-High

3. **MildDemented** (Moderate Stage)
   - Moderate cognitive decline
   - Clear memory and thinking problems
   - Confidence: Medium

4. **ModerateDemented** (Advanced Stage)
   - Severe cognitive decline
   - Significant memory loss
   - Confidence: Medium-High

## 🛠️ Configuration

### Processing Parameters

```python
# Image enhancement settings
processor.contrast_factor = 1.2      # Contrast enhancement
processor.brightness_factor = 1.1    # Brightness adjustment
processor.sharpen_factor = 1.5       # Sharpening intensity

# Model settings
processor.img_size = (224, 224)      # Input image size
processor.class_names = [...]         # Classification classes
```

### Model Architecture

The default CNN architecture includes:

- **4 Convolutional Blocks** with increasing filters (32→64→128→256)
- **Batch Normalization** for training stability
- **Dropout Layers** for regularization
- **Dense Layers** for classification
- **Softmax Output** for multi-class prediction

## 🐛 Troubleshooting

### Common Issues

#### 1. Model Loading Errors

```python
# Check if model file exists
import os
if os.path.exists('models/best_model.h5'):
    processor = MRIScanProcessor('models/best_model.h5')
else:
    # Use default model
    processor = MRIScanProcessor()
```

#### 2. Image Processing Errors

```python
# Check image format
from PIL import Image
try:
    img = Image.open('mri_scan.jpg')
    print(f"Image size: {img.size}")
    print(f"Image mode: {img.mode}")
except Exception as e:
    print(f"Image error: {e}")
```

#### 3. Memory Issues

```python
# Reduce batch size for large images
processor.img_size = (128, 128)  # Smaller input size

# Process images one at a time
for image_path in image_paths:
    analysis = processor.predict_alzheimers_stage(image_path)
```

### Debug Mode

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Enable detailed logging
processor = MRIScanProcessor()
```

## 📈 Performance Optimization

### GPU Acceleration

```python
# Check GPU availability
import tensorflow as tf
print(f"GPU Available: {tf.config.list_physical_devices('GPU')}")

# Enable GPU memory growth
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    tf.config.experimental.set_memory_growth(gpus[0], True)
```

### Batch Processing Optimization

```python
# Process multiple images efficiently
def process_batch_efficiently(image_paths, batch_size=4):
    results = []
    for i in range(0, len(image_paths), batch_size):
        batch = image_paths[i:i+batch_size]
        batch_results = processor.batch_process(batch)
        results.extend(batch_results)
    return results
```

## 🔒 Security & Privacy

### Data Protection

- **Local Processing**: All analysis done locally
- **No Data Storage**: Images processed in memory
- **Secure Uploads**: File validation and sanitization
- **Privacy Compliance**: HIPAA-compliant processing

### Best Practices

```python
# Secure file handling
import hashlib
def secure_filename(filename):
    # Generate secure filename
    hash_name = hashlib.md5(filename.encode()).hexdigest()
    return f"{hash_name}_{filename}"

# Validate file type
def validate_mri_file(file_path):
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.tiff'}
    return any(file_path.lower().endswith(ext) for ext in allowed_extensions)
```

## 📚 Examples

### Complete Analysis Example

```python
from mri_processor import MRIScanProcessor
import matplotlib.pyplot as plt

# Initialize processor
processor = MRIScanProcessor()

# Analyze MRI scan
analysis = processor.predict_alzheimers_stage('patient_scan.jpg')

# Create visualization
viz_path = processor.create_analysis_visualization(
    'patient_scan.jpg', 
    analysis
)

# Generate report
report_path = processor.generate_report(analysis)

# Display results
print(f"Analysis complete!")
print(f"Visualization: {viz_path}")
print(f"Report: {report_path}")
```

### Integration with Web Application

```python
# Flask route for MRI analysis
@app.route('/analyze_mri', methods=['POST'])
def analyze_mri():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Save and process file
    filepath = save_uploaded_file(file)
    analysis = processor.predict_alzheimers_stage(filepath)
    
    return jsonify(analysis)
```

## 📞 Support

For technical support and questions:

1. **Check Logs**: Review application logs for error details
2. **Test Components**: Use `example_mri_analysis.py` for testing
3. **Verify Dependencies**: Ensure all packages are installed
4. **Check Documentation**: Review this guide for solutions

---

**⚠️ Medical Disclaimer**: This system is designed for research and educational purposes. Always consult qualified medical professionals for clinical decisions.
